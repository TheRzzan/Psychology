package com.morozov.psychology.mvp.presenters.mind.change.homework.commitment

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.morozov.psychology.mvp.views.mind.change.homework.commitment.HmCommitment_2_View
import com.morozov.psychology.mvp.views.mind.change.homework.main.HmMainView

@InjectViewState
class HmCommitment_2_Presenter: MvpPresenter<HmCommitment_2_View>() {
}