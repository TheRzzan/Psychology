package com.morozov.psychology.mvp.models.tests.about.enums

enum class MaritalStatusEnum {
    SINGLE,
    MARRIED,
    DIVORCED,
    WIDOWER
}