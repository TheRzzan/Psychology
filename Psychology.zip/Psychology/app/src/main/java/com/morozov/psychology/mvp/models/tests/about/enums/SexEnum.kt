package com.morozov.psychology.mvp.models.tests.about.enums

enum class SexEnum {
    MAN,
    WOMAN
}