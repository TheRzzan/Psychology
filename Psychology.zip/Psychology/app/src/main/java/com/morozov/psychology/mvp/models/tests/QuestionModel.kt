package com.morozov.psychology.mvp.models.tests

data class QuestionModel(val question: String, val answers: List<String>)
