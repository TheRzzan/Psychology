package com.morozov.psychology.mvp.models.examples

data class FixingModel(val situation: String, val pairs: List<Pair<String, String>>)