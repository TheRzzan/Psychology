package com.morozov.psychology.mvp.models.tests.about.enums

enum class FrequencyOfUseEnum {
    EVERYDAY,
    EVERYWEEK,
    EVERYMONTH,
    LESS_OFTEN
}