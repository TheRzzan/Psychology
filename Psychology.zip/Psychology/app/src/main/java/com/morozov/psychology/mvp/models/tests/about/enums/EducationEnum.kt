package com.morozov.psychology.mvp.models.tests.about.enums

enum class EducationEnum {
    PRIMARY,
    SECONDARY,
    SECONDARY_VOCATIONAL,
    HIGHER_VOCATIONAL
}