package com.morozov.psychology.mvp.presenters.mind.change.changing.disastorous

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.morozov.psychology.mvp.views.mind.change.changing.disastorous.MCDisastorous_2_View

@InjectViewState
class MCDisastorous_2_Presenter: MvpPresenter<MCDisastorous_2_View>() {

}