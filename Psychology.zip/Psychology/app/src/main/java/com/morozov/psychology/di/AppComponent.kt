package com.morozov.psychology.di

interface AppComponent {
}