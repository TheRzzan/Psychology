package com.morozov.psychology.mvp.presenters.mind.change.changing.deprecation

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.morozov.psychology.mvp.views.mind.change.changing.deprecation.MCDeprecation_2_View

@InjectViewState
class MCDeprecation_2_Presenter: MvpPresenter<MCDeprecation_2_View>() {
}