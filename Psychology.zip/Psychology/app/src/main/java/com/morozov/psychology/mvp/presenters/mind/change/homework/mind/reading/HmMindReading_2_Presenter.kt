package com.morozov.psychology.mvp.presenters.mind.change.homework.mind.reading

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.morozov.psychology.mvp.views.mind.change.homework.main.HmMainView
import com.morozov.psychology.mvp.views.mind.change.homework.mind.reading.HmMindReading_2_View

@InjectViewState
class HmMindReading_2_Presenter: MvpPresenter<HmMindReading_2_View>() {
}