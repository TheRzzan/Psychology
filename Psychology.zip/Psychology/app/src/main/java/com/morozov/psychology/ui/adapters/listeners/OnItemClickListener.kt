package com.morozov.psychology.ui.adapters.listeners

import android.view.View

interface OnItemClickListener {

    fun onItemClick(view: View, position: Int)
}