package com.morozov.psychology.mvp.models.examples

data class ExFixingResultModel(val name: String, val userText: String, val trueText: String)