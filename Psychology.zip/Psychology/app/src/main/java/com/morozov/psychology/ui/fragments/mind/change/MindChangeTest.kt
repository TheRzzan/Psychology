package com.morozov.psychology.ui.fragments.mind.change

interface MindChangeTest {
}