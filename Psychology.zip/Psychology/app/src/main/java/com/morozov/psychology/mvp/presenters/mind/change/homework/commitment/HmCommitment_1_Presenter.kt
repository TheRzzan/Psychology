package com.morozov.psychology.mvp.presenters.mind.change.homework.commitment

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.morozov.psychology.mvp.views.mind.change.homework.commitment.HmCommitment_1_View
import com.morozov.psychology.mvp.views.mind.change.homework.main.HmMainView

@InjectViewState
class HmCommitment_1_Presenter: MvpPresenter<HmCommitment_1_View>() {
}