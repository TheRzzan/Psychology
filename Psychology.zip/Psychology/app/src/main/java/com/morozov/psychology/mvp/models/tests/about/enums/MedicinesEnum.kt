package com.morozov.psychology.mvp.models.tests.about.enums

enum class MedicinesEnum {
    ANTIDEPRESSANTS,
    TRANQUILIZERS,
    ANTIPSYCHOTICS,
    NORMOTIMICS
}