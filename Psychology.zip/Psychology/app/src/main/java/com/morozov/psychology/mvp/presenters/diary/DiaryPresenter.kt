package com.morozov.psychology.mvp.presenters.diary

import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.morozov.psychology.DefaultApplication
import com.morozov.psychology.domain.interfaces.diary.ThinkDeleter
import com.morozov.psychology.domain.interfaces.diary.ThinkLoader
import com.morozov.psychology.domain.interfaces.diary.ThinkSaver
import com.morozov.psychology.mvp.models.diary.ThinkModel
import com.morozov.psychology.mvp.views.diary.DiaryView
import com.morozov.psychology.utility.DateConverter
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@InjectViewState
class DiaryPresenter: MvpPresenter<DiaryView>() {

    @Inject
    lateinit var thinkLoader: ThinkLoader

    @Inject
    lateinit var thinkSaver: ThinkSaver

    @Inject
    lateinit var thinkDeleter: ThinkDeleter

    init {
        DefaultApplication.diaryComponent.inject(this)
    }

    companion object {
        var currentDate = -1
    }

    var lastMonthData: MutableList<MutableList<ThinkModel>> = mutableListOf()
    var dateList: MutableList<Date> = mutableListOf()

    fun loadData(dateC: Date? = null) {
        lastMonthData = mutableListOf()
        dateList = mutableListOf()

        val thinksAll = thinkLoader.getThinks()
        val thinksLastMonth: MutableList<ThinkModel> = mutableListOf()
        val elements: MutableList<Pair<Int, String>> = mutableListOf()

        val dayFormat = SimpleDateFormat("dd")
        val monthFormat = SimpleDateFormat("MM")
        val monthYearFormat = SimpleDateFormat("MM/yyyy")
        val dayMtYrFormat = SimpleDateFormat("dd/MM/yyyy")

        val todayDate = Date()

        for (item in thinksAll) {
            if (monthYearFormat.format(item.date) == monthYearFormat.format(todayDate) ||
                (dateC != null && monthYearFormat.format(item.date) == monthYearFormat.format(dateC)))
                thinksLastMonth.add(item)
        }

        if (dateC != null) {
            thinksLastMonth.add(ThinkModel(dateC, "", "", arrayListOf(), ""))
            thinksLastMonth.sort()
        }

        var listTmp = mutableListOf<ThinkModel>()
        for (item in thinksLastMonth) {
            if (dateList.isEmpty() ||
                dayMtYrFormat.format(item.date) != dayMtYrFormat.format(dateList[dateList.size - 1])) {

                dateList.add(item.date)
                elements.add(
                    Pair(
                        dayFormat.format(item.date).toInt(),
                        DateConverter.getStringMonthSimple(monthFormat.format(item.date))
                    )
                )

                listTmp = mutableListOf()
                lastMonthData.add(listTmp)
            }

            if (dateC != null && item.date.compareTo(dateC) == 0)
                currentDate = elements.size - 1
            else
                listTmp.add(item)
        }

        if (dateList.isEmpty() || dayMtYrFormat.format(todayDate) != dayMtYrFormat.format(dateList[dateList.size - 1])) {
            elements.add(
                Pair(
                    dayFormat.format(todayDate).toInt(),
                    DateConverter.getStringMonthSimple(monthFormat.format(todayDate))
                )
            )

            lastMonthData.add(mutableListOf())
            dateList.add(todayDate)
        }

        if (currentDate < 0 || currentDate >= elements.size)
            currentDate = elements.size - 1

        viewState.showDates(dateList)
    }

    fun deleteThink(think: ThinkModel): ThinkModel? {
        lastMonthData[currentDate].remove(think)
        thinkDeleter.deleteThink(think)
        return think
    }

    fun addThink(index: Int, think: ThinkModel) {
        lastMonthData[currentDate].add(index, think)
        thinkSaver.saveNew(think)
    }

    fun calendarDateSelected(date: Date) {
        loadData(date)
    }

    fun selectDay(position: Int) {
        currentDate = position

        if (position >= lastMonthData.size || lastMonthData.isEmpty())
            return

        viewState.showThinkList(lastMonthData[position])
    }
}