package com.morozov.psychology.ui.adapters.listeners

interface OnTextChangeListener {

    fun onTextChanged(position: Int, count: Int, symbolSet: String, percent: Int? = null)
}